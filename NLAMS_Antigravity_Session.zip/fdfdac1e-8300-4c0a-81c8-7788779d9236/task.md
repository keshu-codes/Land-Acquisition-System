# Role-Based JWT Authentication Checklist

- [x] Backend Implementation
    - [x] Add User SQLModel schemas (`User`, `UserRead`, `UserLogin`) in `models.py`
    - [x] Configure JWT helpers and passlib bcrypt context in `dependencies.py`
    - [x] Create `auth.py` router with `/login` and `/me` endpoints
    - [x] Seed 5 demo user accounts in `database.py` on startup
    - [x] Register `auth.py` router in `main.py`
- [x] Frontend Implementation
    - [x] Create `Login.jsx` page component with 1-click Quick Login demo presets
    - [x] Integrate Auth state and JWT header management in `AppContext.jsx`
    - [x] Update `Navbar.jsx` with user profile status and Logout action
    - [x] Guard routes and protected actions in `App.jsx` and pages
- [x] Verification
    - [x] Run backend server and test authentication flow
    - [x] Run Vite frontend build and test end-to-end login/logout functionality
