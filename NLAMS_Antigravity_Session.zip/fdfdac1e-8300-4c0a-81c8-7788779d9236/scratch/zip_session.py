import zipfile
import os

source_dir = r"C:\Users\win11\.gemini\antigravity\brain\fdfdac1e-8300-4c0a-81c8-7788779d9236"
output_zip = r"c:\Users\win11\Downloads\sih\NLAMS_Antigravity_Session.zip"

print("Compressing Antigravity session brain folder...")

with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(source_dir):
        for file in files:
            file_path = os.path.join(root, file)
            # Preserve relative structure starting from conversation ID
            rel_path = os.path.relpath(file_path, os.path.dirname(source_dir))
            zipf.write(file_path, rel_path)

print(f"Antigravity session successfully zipped to: {output_zip}")
