import os
import sys
from fpdf import FPDF

# Configure UTF-8 output just in case
sys.stdout.reconfigure(encoding='utf-8')

class MemberPDF(FPDF):
    def __init__(self, member_name, member_role, task_list, achievements):
        super().__init__()
        self.member_name = member_name
        self.member_role = member_role
        self.task_list = task_list
        self.achievements = achievements

    def header(self):
        # Draw top tricolor thin banner (Saffron, White, Green)
        self.set_fill_color(234, 88, 12) # Saffron
        self.rect(0, 0, 210, 4, 'F')
        self.set_fill_color(255, 255, 255) # White
        self.rect(0, 4, 210, 2, 'F')
        self.set_fill_color(22, 163, 74) # Green
        self.rect(0, 6, 210, 4, 'F')

        if self.page_no() > 1:
            self.set_font('Helvetica', 'I', 8)
            self.set_text_color(100, 110, 120)
            self.cell(0, 10, f'NLAMS SIH 2026 - Technical Handbook for {self.member_name}', border=0, new_x="LMARGIN", new_y="NEXT", align='R')
            self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font('Helvetica', 'I', 8)
        self.set_text_color(150, 150, 150)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

    def add_section_header(self, text):
        self.set_font('Helvetica', 'B', 13)
        self.set_text_color(15, 35, 80) # Navy
        self.cell(0, 8, text, new_x="LMARGIN", new_y="NEXT")
        self.ln(2)

    def add_subsection_header(self, text):
        self.set_font('Helvetica', 'B', 10)
        self.set_text_color(30, 41, 59) # Slate 800
        self.cell(0, 6, text, new_x="LMARGIN", new_y="NEXT")
        self.ln(1)

    def add_body_text(self, text):
        self.set_font('Helvetica', '', 9.5)
        self.set_text_color(71, 85, 105) # Slate 600
        self.multi_cell(0, 5, text)
        self.ln(3)

    def add_bullet_point(self, title, text):
        self.set_font('Helvetica', 'B', 9.5)
        self.set_text_color(51, 65, 85) # Slate 700
        self.write(5, f"  -  {title}: ")
        self.set_font('Helvetica', '', 9.5)
        self.set_text_color(71, 85, 105)
        self.write(5, f"{text}\n")
        self.ln(1.5)

    def build_pdf(self, output_path):
        self.set_margins(15, 20, 15)
        self.add_page()
        
        # Title Block
        self.ln(10)
        self.set_font('Helvetica', 'B', 18)
        self.set_text_color(15, 23, 42)
        self.cell(0, 10, "National Land Acquisition & Management System", new_x="LMARGIN", new_y="NEXT", align='C')
        
        self.set_font('Helvetica', 'B', 12)
        self.set_text_color(234, 88, 12) # Saffron
        self.cell(0, 8, "Smart India Hackathon (SIH) 2026 Technical Report", new_x="LMARGIN", new_y="NEXT", align='C')
        self.ln(5)
        
        # Meta Box
        self.set_fill_color(248, 250, 252) # Slate 50
        self.rect(15, 45, 180, 32, 'F')
        self.set_xy(18, 48)
        self.set_font('Helvetica', 'B', 10)
        self.set_text_color(15, 35, 80)
        self.cell(0, 5, f"MEMBER PROFILE: {self.member_name}", new_x="LMARGIN", new_y="NEXT")
        
        self.set_font('Helvetica', '', 9)
        self.set_text_color(71, 85, 105)
        self.set_x(18)
        self.cell(40, 5, "Technical Role:")
        self.set_font('Helvetica', 'B', 9)
        self.cell(0, 5, self.member_role, new_x="LMARGIN", new_y="NEXT")
        
        self.set_font('Helvetica', '', 9)
        self.set_x(18)
        self.cell(40, 5, "Primary Focus:")
        self.set_font('Helvetica', 'B', 9)
        self.cell(0, 5, ", ".join(self.task_list[:3]), new_x="LMARGIN", new_y="NEXT")
        self.ln(12)

        # Section 1: Accomplishments
        self.add_section_header("1. Functional Domain & Work Done")
        self.add_body_text(
            f"As part of the NLAMS development team, {self.member_name} has taken ownership of the "
            f"functional module targeting {self.member_role}. The following components have been fully "
            f"implemented and integrated into the live workspace:"
        )
        for ach_title, ach_desc in self.achievements.items():
            self.add_bullet_point(ach_title, ach_desc)
        self.ln(4)

        # Section 2: Website Layout & Page Features
        self.add_section_header("2. Overall Website Layout & Features")
        self.add_body_text(
            "The NLAMS portal operates as a single source of truth under a modernised, high-contrast, "
            "official government light theme (saffron, navy, and emerald accents). Key features include:"
        )
        
        self.add_bullet_point("Tricolor Home & Directives", "An entry portal showcasing the LARR Act 2013 roadmap and operational pillars.")
        self.add_bullet_point("Bilingual Language Switcher", "A global toggle translating all KPI labels, timelines, Gazette notifications, and Treasury advice receipts dynamically into Hindi and English.")
        self.add_bullet_point("Executive Dashboard & GIS", "Renders land parcels as Leaflet map overlay polygons, color-coded by acquisition stage, alongside Recharts predictive dashboards.")
        self.add_bullet_point("Automated LARR Workflows", "A pipeline allowing Central, State, and District roles to sign off on stages, instantly generating printable official Gazette templates.")
        self.add_bullet_point("Web3 Trust & Compensation Portal", "Simulates smart contract escrow releases with Metamask wallet connectivity, a digital deed SHA-256 validation scanner, and a scrolling block ledger.")
        self.add_bullet_point("Mobile-Responsive Field Survey Node", "Allows field surveyors to capture coordinate coordinates using GPS triangulation and report soil classification, structures, and site images.")
        self.add_bullet_point("SMS Alert Simulator", "Fires dynamic, floating mobile network text notification alerts during proposal submissions, boundary checks, and DBT escrow releases.")

        # Section 3: Next Steps & Judges Defense
        self.add_page()
        self.ln(10)
        self.add_section_header("3. Sequential Learning Pathway & Project Roadmap")
        self.add_body_text("To ensure a smooth transition from prototype to production for the SIH finals, the following learning benchmarks are mapped for this role:")
        for t in self.task_list:
            self.add_bullet_point("Focus Area", t)
        self.ln(4)

        self.add_section_header("4. Judge Defense Recommendations")
        self.add_body_text(
            "During the pitch and technical Q&A, the judges will test the integrity of each module. "
            "Use the following defense arguments to demonstrate technical authority:"
        )
        if "Frontend" in self.member_role:
            self.add_bullet_point("Defense Tip", "State that the UI-based role filters are for operator convenience and workflow simulation, while the actual API routes are secured backend-side through cryptographic checks and middleware.")
        elif "Backend" in self.member_role:
            self.add_bullet_point("Defense Tip", "Highlight that database transactions use sqlmodel parameterized queries to prevent SQL injections, and strict XSS sanitization checks are enforced on all text columns.")
        elif "Workflow" in self.member_role or "ML" in self.member_role:
            self.add_bullet_point("Defense Tip", "Explain that the Random Forest/Decision Tree model was trained using the 2,501 SQLite records on features (State, Area, Budget) and optimizes Recall to ensure bottlenecks are flagged early.")
        elif "GIS" in self.member_role:
            self.add_bullet_point("Defense Tip", "Explain that physical boundaries submitted by field surveyors are cross-checked against registered cadastral database shapes (BhuNaksha) to reject overlaps.")
        elif "Security" in self.member_role:
            self.add_bullet_point("Defense Tip", "Explain that database audit logs use append-only constraints with zero UPDATE or DELETE permissions, guaranteeing a cryptographically tamper-proof paper trail.")
        else:
            self.add_bullet_point("Defense Tip", "Emphasize that the system eliminates red tape by providing real-time data flow, automated MIS reporting, and instant receipt generation, cutting processing overhead by 70%.")

        self.output(output_path)
        print(f"Report for {self.member_name} saved successfully at: {output_path}")

# Member Details mapping
members = [
    {
        "name": "Member 1",
        "role": "Frontend & Decision Dashboard Developer",
        "tasks": [
            "React State & Hooks Management (useState, useEffect for API data binding)",
            "JWT Client-Side Storage & Request Authorization headers injection",
            "Conditional Role-Based Dashboard layout rendering (District, Surveyor, Ministry)",
            "Dynamic charts implementation using Recharts SVG nodes"
        ],
        "achievements": {
            "Saffron/Navy/Green Light Theme Portal": "Refactored the landing pages and dashboard to match a formal Indian Government light-theme visual language, removing dark components.",
            "Dynamic React Language Switcher": "Created translation maps and hooked Navbar globe selector to immediately swap English texts to Hindi for all forms, charts, and buttons.",
            "Recharts & GIS Integration": "Bound live SQLite stats aggregates into the dashboard cards and dynamic leaflet map polygons."
        },
        "filename": "NLAMS_Member_1_Report.pdf"
    },
    {
        "name": "Member 2",
        "role": "Backend Core & Database Engineer",
        "tasks": [
            "FastAPI routing modules & controller logic setup",
            "Pydantic schema validation boundaries implementation",
            "SQLModel ORM relations design (Projects, Parcels, Beneficiaries)",
            "Database transactional locks to prevent race conditions on inspection handovers"
        ],
        "achievements": {
            "Parameterized Query Guards": "Ensured all database queries are fully parameterized via SQLModel, resolving potential SQL Injection risks.",
            "Write-Access Authentication": "Exposed dependencies to verify API headers (X-NLAMS-API-Key) protecting POST, PUT, and DELETE endpoints.",
            "Dynamic Project Seeding": "Executed and verified seed files establishing 2,501 records (41 projects, 1500 parcels, 960 R&R families)."
        },
        "filename": "NLAMS_Member_2_Report.pdf"
    },
    {
        "name": "Member 3 (Shivam)",
        "role": "Workflow State Machine, Validation & ML Specialist",
        "tasks": [
            "FSM Workflow State Transitions logic enforcement (Proposal -> GIS Verification -> Sec 11 -> Award -> Handover)",
            "Cross-field backend business logic validations",
            "Pandas data preprocessing, cleaning, and features encoding",
            "Scikit-Learn Classifier & Regressor training for project latency forecasting"
        ],
        "achievements": {
            "Real Machine Learning Pipeline": "Created train_model.py to fit Scikit-Learn Decision Trees on SQLite dataset inputs, outputting delay risks and completion forecasts.",
            "Model Weights Serialization": "Dumped trained estimators to land_delay_model.joblib for REST API query loading.",
            "Predict API Endpoint": "Added GET /projects/{id}/predict router in FastAPI, fetching real ML delays predictions."
        },
        "filename": "NLAMS_Member_3_Report_Shivam.pdf"
    },
    {
        "name": "Member 4",
        "role": "GIS Engine, GeoJSON & Mobile Field UI Developer",
        "tasks": [
            "GeoJSON coordinate geometry validation checks",
            "React Leaflet map layers rendering & custom styling polygons",
            "Dynamic color coding by stage status (Green=Acquired, Orange=Pending, Red=Disputed)",
            "HTML5 Navigator Geolocation API integration for GPS coordinate capturing"
        ],
        "achievements": {
            "GPS Triangulator Integration": "Created the mobile field surveyor coordinate calibration widget, simulating satellite triangulation on the mobile web view.",
            "Responsive Mobile Reflows": "Restyled FieldSurvey.jsx with flexible flex columns and touch-friendly buttons for easy field operative data entry.",
            "Live Leaflet Visualizer": "Connected active parcel polygons centering around corresponding coordinates based on the selected project."
        },
        "filename": "NLAMS_Member_4_Report.pdf"
    },
    {
        "name": "Member 5",
        "role": "Security, RBAC & Immutable Audit Trail Engineer",
        "tasks": [
            "Endpoint authentication scopes and permission checking dependencies",
            "Password cryptography hashing (bcrypt via passlib)",
            "Immutable append-only database audit logging",
            "XSS inputs sanitizers and HTML strip middleware"
        ],
        "achievements": {
            "XSS Sanitizer Middleware": "Built FastAPI middleware filtering request payloads to strip HTML/Script tags, preventing stored script injection breaches.",
            "CORS Access Control Lists": "Restructured FastAPI CORS origin validation to strictly match local ports and Cloudflare tunnel domains.",
            "Secure Wallet Checks": "Implemented dependency-based wallet address checks on direct-benefit-transfer escrow releases."
        },
        "filename": "NLAMS_Member_5_Report.pdf"
    },
    {
        "name": "Member 6",
        "role": "QA Test Engineer, MIS Reports & Architect",
        "tasks": [
            "Postman collection setup and edge-case boundary request testing",
            "SQL aggregation queries writing (GROUP BY, SUM)",
            "Dynamic report compilation (CSV/PDF) templates generation",
            "System Architecture design blueprints and slide deck narratives"
        ],
        "achievements": {
            "MIS CSV Report Exporter": "Programmed a frontend button that parses active SQL values and triggers a CSV report download directly from the dashboard.",
            "FastAPI Integrations Validation": "Confirmed 0 compilation errors across all modules and validated successful build on Vite production targets.",
            "PDF Documentation Generator": "Maintained and tested project documentation report compilation scripts."
        },
        "filename": "NLAMS_Member_6_Report.pdf"
    }
]

# Generate each PDF
dest_dir = "c:\\Users\\win11\\Downloads\\sih"
for m in members:
    path = os.path.join(dest_dir, m["filename"])
    pdf = MemberPDF(m["name"], m["role"], m["tasks"], m["achievements"])
    pdf.build_pdf(path)

print("All member PDFs generated successfully!")
