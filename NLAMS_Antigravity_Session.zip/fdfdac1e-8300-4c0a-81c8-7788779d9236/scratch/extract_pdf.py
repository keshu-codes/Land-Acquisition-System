import sys
from pypdf import PdfReader

reader = PdfReader("c:\\Users\\win11\\Downloads\\Land_Acquisition_System_Team_Roadmap.pdf")
output_txt = "C:\\Users\\win11\\.gemini\\antigravity\\brain\\fdfdac1e-8300-4c0a-81c8-7788779d9236\\scratch\\roadmap_text.txt"

with open(output_txt, "w", encoding="utf-8") as f:
    f.write(f"Number of pages: {len(reader.pages)}\n")
    for i, page in enumerate(reader.pages):
        f.write(f"\n--- PAGE {i+1} ---\n")
        f.write(page.extract_text() or "")

print("Text successfully written to:", output_txt)
