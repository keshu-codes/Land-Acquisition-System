import os
import sys
from fpdf import FPDF

# Configure UTF-8
sys.stdout.reconfigure(encoding='utf-8')

class HandbookPDF(FPDF):
    def header(self):
        # Tricolor header bar
        self.set_fill_color(234, 88, 12) # Saffron
        self.rect(0, 0, 210, 4, 'F')
        self.set_fill_color(255, 255, 255) # White
        self.rect(0, 4, 210, 2, 'F')
        self.set_fill_color(22, 163, 74) # Green
        self.rect(0, 6, 210, 4, 'F')

        if self.page_no() > 1:
            self.set_font('Helvetica', 'I', 8)
            self.set_text_color(100, 110, 120)
            self.cell(0, 10, 'NLAMS - SIH 2026 Team Study Handbook', border=0, new_x="LMARGIN", new_y="NEXT", align='R')
            self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font('Helvetica', 'I', 8)
        self.set_text_color(150, 150, 150)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

    def add_section_header(self, text):
        self.set_font('Helvetica', 'B', 14)
        self.set_text_color(15, 35, 80) # Navy
        self.cell(0, 10, text, new_x="LMARGIN", new_y="NEXT")
        self.ln(2)

    def add_subsection_header(self, text):
        self.set_font('Helvetica', 'B', 11)
        self.set_text_color(30, 41, 59) # Slate 800
        self.cell(0, 8, text, new_x="LMARGIN", new_y="NEXT")
        self.ln(1)

    def add_body_text(self, text):
        self.set_font('Helvetica', '', 10)
        self.set_text_color(71, 85, 105) # Slate 600
        self.multi_cell(0, 5.5, text)
        self.ln(3)

    def add_bullet_point(self, title, text):
        self.set_font('Helvetica', 'B', 10)
        self.set_text_color(51, 65, 85) # Slate 700
        self.write(5.5, f"  -  {title}: ")
        self.set_font('Helvetica', '', 10)
        self.set_text_color(71, 85, 105)
        self.write(5.5, f"{text}\n")
        self.ln(2)

# Create PDF
pdf = HandbookPDF()
pdf.set_margins(15, 20, 15)
pdf.add_page()

# Title
pdf.ln(10)
pdf.set_font('Helvetica', 'B', 20)
pdf.set_text_color(15, 23, 42)
pdf.cell(0, 10, "National Land Acquisition & Management System", new_x="LMARGIN", new_y="NEXT", align='C')

pdf.set_font('Helvetica', 'B', 12)
pdf.set_text_color(234, 88, 12) # Saffron
pdf.cell(0, 8, "SIH 2026 Hackathon Team Study Handbook", new_x="LMARGIN", new_y="NEXT", align='C')
pdf.ln(5)

# Page 1 Intro
pdf.add_section_header("1. Team Members & Technical Part Assignments")
pdf.add_body_text(
    "This handbook outlines each team member's role and technical assignments for the NLAMS prototype. "
    "Study your corresponding section below to understand your part of the project code and database design:"
)

# Member 1
pdf.add_subsection_header("Member 1: React UI & Dashboard Developer")
pdf.add_body_text(
    "Responsible for the visual layout, user dashboard, styling, and localization switchers. "
    "Key assignments include: React state hooks (useState, useEffect) for dynamic API binding; "
    "implementing the saffron, navy, and emerald government light-theme visual language; building the "
    "global Hindi/English translation maps (Translation.js) for all labels, timelines, forms, and buttons; "
    "and rendering the predictive graphs and compensation progress bars using Recharts SVG charts."
)

# Member 2
pdf.add_subsection_header("Member 2: Backend Core & Database Engineer")
pdf.add_body_text(
    "Responsible for the server endpoints, relational database design, data persistence, and seeding. "
    "Key assignments include: setting up FastAPI async routing and controllers; designing the sqlmodel "
    "ORM tables with project, parcel, and beneficiary schemas; implementing parameterised query guards to "
    "eliminate SQL injection risks; enforcing secure write-access checks using API keys; and executing the "
    "sqlite seeding script to populate the database with a realistic test set of 2,501 records."
)

# Member 3
pdf.add_subsection_header("Member 3 (Shivam): Workflow State Machine & ML Specialist")
pdf.add_body_text(
    "Responsible for business validation logic, the LARR workflow state machine, and delay predictions. "
    "Key assignments include: coding the LARR sequence validation (Submitted -> GIS check -> Sec 11 legal "
    "notice -> Award -> Handover); pre-processing raw SQLite project data with Pandas; training the "
    "Scikit-Learn Classifier and Regressor models; saving weights to land_delay_model.joblib; and deploying the "
    "GET /projects/{id}/predict REST API endpoint to output live machine learning delay risk predictions."
)

# Member 4
pdf.add_subsection_header("Member 4: GIS Engine & Mobile Field UI Developer")
pdf.add_body_text(
    "Responsible for geographical mapping overlays, GeoJSON geometry, and mobile responsiveness. "
    "Key assignments include: integrating Leaflet maps inside React Components; parsing and rendering parcel "
    "GeoJSON boundaries as styled interactive polygons; color-coding parcels dynamically by status "
    "(Green = Acquired, Orange = Pending, Red = Disputed); and implementing HTML5 Geolocation sensors to "
    "allow surveyors to capture coordinates on-site with touch-friendly layout reflows."
)

# Member 5
pdf.add_subsection_header("Member 5: Security, RBAC & Audit Logger")
pdf.add_body_text(
    "Responsible for cybersecurity hardening, payload sanitization, and immutable logging. "
    "Key assignments include: implementing password hashing algorithms (bcrypt via passlib); coding global "
    "FastAPI middleware to strip HTML/Script tags from incoming payloads to prevent stored XSS attacks; "
    "configuring strict CORS origin lists to limit access to approved local ports and Cloudflare tunnels; "
    "and checking wallet address signatures during MetaMask DBT escrow fund disbursements."
)

# Member 6
pdf.add_subsection_header("Member 6: QA Testing, MIS Reports & Presentation Lead")
pdf.add_body_text(
    "Responsible for testing, compiling summaries, generating files, and structure of the deck. "
    "Key assignments include: writing the frontend MIS Exporter button to parse project arrays and compile "
    "them into downloadable CSV spreadsheets; running edge-case API tests via Swagger UI; validating "
    "successful build operations across the Vite compiler; and structuring the 3-minute pitch deck narrative "
    "explaining the system's operational pillars and real-world impact to the judges."
)

# --- PAGE 2 (All extra stuff) ---
pdf.add_page()
pdf.ln(10)

pdf.add_section_header("2. Website Architecture & Layout Features")
pdf.add_bullet_point("Tricolor Home & Directives", "Official national entry portal showcasing the LARR Act 2013 timeline and animated highlights of operational pillars.")
pdf.add_bullet_point("Bilingual Language Switcher", "A globe selector in the navbar translating charts, forms, and official Gazette forms dynamically to Hindi.")
pdf.add_bullet_point("Executive Dashboard & GIS", "Renders land parcels as Leaflet map overlay polygons alongside Recharts predictive dashboards.")
pdf.add_bullet_point("Automated Workflows", "A pipeline allowing Central, State, and District roles to sign off on stages, instantly generating printable official Gazette templates.")
pdf.add_bullet_point("Web3 Trust Portal", "Simulates smart contract escrow releases with Metamask wallet connectivity, a digital deed SHA-256 validation scanner, and a scrolling block ledger.")
pdf.add_bullet_point("Mobile Field Survey Node", "Allows field surveyors to capture coordinate coordinates using GPS triangulation and report soil classification, structures, and site images.")
pdf.add_bullet_point("SMS Alert Simulator", "Fires dynamic, floating mobile network text notification alerts during proposal submissions, boundary checks, and DBT escrow releases.")
pdf.add_bullet_point("AI Delay Forecasting", "The Scikit-Learn model endpoint checking administrative bottlenecks.")
pdf.ln(4)

pdf.add_section_header("3. Technical Stack Breakdown")
pdf.add_bullet_point("Frontend Framework", "React.js built on Vite (Vite 8, React 19) for immediate loading times and HMR (Hot Module Replacement).")
pdf.add_bullet_point("Styling Stack", "Tailwind CSS v4 for fully custom responsive components, clean government-themed color palettes, and layouts.")
pdf.add_bullet_point("GIS Map Rendering", "React Leaflet & Leaflet.js utilizing OpenStreetMap tile layers to draw and render coordinate boundaries (polygons).")
pdf.add_bullet_point("MIS Visual Charts", "Recharts package using SVG elements for responsive financial and progress bar graphs.")
pdf.add_bullet_point("Web3 Simulation", "Context-based mock ledger engine simulating SHA-256 hashes, transaction block creation, and crypto signatures.")
pdf.ln(4)

pdf.add_section_header("4. Pitch Defense Strategy for Team Members")
pdf.add_bullet_point("React UI (M1)", "UI-based role selectors are for operator convenience and workflow simulation, while the actual API routes are secured backend-side through cryptographic checks and middleware.")
pdf.add_bullet_point("Backend (M2)", "Database transactions use sqlmodel parameterized queries to prevent SQL injections, and strict XSS sanitization checks are enforced on all text columns.")
pdf.add_bullet_point("Workflow & ML (Shivam)", "The Random Forest/Decision Tree model was trained using the 2,501 SQLite records on features (State, Area, Budget) and optimizes Recall to ensure bottlenecks are flagged early.")
pdf.add_bullet_point("GIS (M4)", "Physical boundaries submitted by field surveyors are cross-checked against registered cadastral database shapes (BhuNaksha) to reject overlaps.")
pdf.add_bullet_point("Security (M5)", "Database audit logs use append-only constraints with zero UPDATE or DELETE permissions, guaranteeing a cryptographically tamper-proof paper trail.")

# Save to disk
output_path = os.path.join("c:\\Users\\win11\\Downloads\\sih", "NLAMS_Team_Handbook.pdf")
pdf.output(output_path)
print(f"Team Study Handbook saved successfully at: {output_path}")
