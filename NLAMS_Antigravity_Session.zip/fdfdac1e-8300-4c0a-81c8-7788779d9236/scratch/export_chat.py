import json
import os
import re

log_file = r"C:\Users\win11\.gemini\antigravity\brain\fdfdac1e-8300-4c0a-81c8-7788779d9236\.system_generated\logs\transcript.jsonl"
output_html = r"c:\Users\win11\Downloads\sih\NLAMS_Chat_History.html"

messages = []

if os.path.exists(log_file):
    with open(log_file, "r", encoding="utf-8") as f:
        for line in f:
            try:
                data = json.loads(line)
                step_type = data.get("type")
                source = data.get("source")
                content = data.get("content", "")

                if step_type == "USER_INPUT" and content:
                    # Strip tags if any
                    clean_text = re.sub(r'<[^>]+>', '', content).strip()
                    if clean_text:
                        messages.append({"sender": "User", "text": clean_text})
                elif step_type == "PLANNER_RESPONSE" and content:
                    # Model response text
                    if content.strip():
                        messages.append({"sender": "Antigravity Assistant", "text": content.strip()})
            except Exception:
                pass

# Generate Styled HTML Document
html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>NLAMS - Full SIH Project Chat Transcript & Study Guide</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f8fafc;
            color: #0f172a;
            margin: 0;
            padding: 30px;
            line-height: 1.6;
        }}
        .container {{
            max-width: 900px;
            margin: 0 auto;
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            padding: 40px;
        }}
        .header {{
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }}
        .header h1 {{
            color: #0f2b5c;
            font-size: 24px;
            margin: 0 0 8px 0;
        }}
        .header p {{
            color: #64748b;
            font-size: 13px;
            margin: 0;
        }}
        .msg {{
            margin-bottom: 24px;
            padding: 20px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
        }}
        .msg-user {{
            background-color: #fff7ed;
            border-color: #fed7aa;
        }}
        .msg-assistant {{
            background-color: #f0f9ff;
            border-color: #bae6fd;
        }}
        .sender-badge {{
            font-weight: 800;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
        }}
        .badge-user {{
            background: #ea580c;
            color: #ffffff;
        }}
        .badge-assistant {{
            background: #0f2b5c;
            color: #ffffff;
        }}
        .text-content {{
            font-size: 14px;
            white-space: pre-wrap;
            word-wrap: break-word;
        }}
        code {{
            background: #e2e8f0;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
        }}
        pre {{
            background: #0f172a;
            color: #f8fafc;
            padding: 16px;
            border-radius: 8px;
            overflow-x: auto;
            font-size: 12px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>National Land Acquisition System (NLAMS)</h1>
            <p>Complete AI Pair-Programming Chat Transcript & Technical Roadmap Log | Smart India Hackathon (SIH) 2026</p>
        </div>
        <div class="chat-log">
"""

for msg in messages:
    is_user = msg["sender"] == "User"
    badge_cls = "badge-user" if is_user else "badge-assistant"
    msg_cls = "msg-user" if is_user else "msg-assistant"
    
    # Escape basic html chars
    text = msg["text"].replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    
    html_content += f"""
            <div class="msg {msg_cls}">
                <span class="sender-badge {badge_cls}">{msg["sender"]}</span>
                <div class="text-content">{text}</div>
            </div>
    """

html_content += """
        </div>
    </div>
</body>
</html>
"""

with open(output_html, "w", encoding="utf-8") as f:
    f.write(html_content)

print(f"Chat history exported successfully to: {output_html}")
