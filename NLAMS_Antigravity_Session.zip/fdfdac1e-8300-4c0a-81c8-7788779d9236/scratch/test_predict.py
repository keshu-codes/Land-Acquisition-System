import os
import sys

# Add backend app directory
sys.path.append("c:\\Users\\win11\\Downloads\\sih\\backend\\home\\nitesh\\Downloads\\M2_LAND_ACQUISITION")

from app.routers.dashboard import predict_delay
from app.database import get_session
from sqlmodel import Session, create_engine

# Setup session
DATABASE_URL = "sqlite:///c:\\Users\\win11\\Downloads\\sih\\backend\\home\\nitesh\\Downloads\\M2_LAND_ACQUISITION\\land_acquisition.db"
engine = create_engine(DATABASE_URL)

with Session(engine) as session:
    try:
        res = predict_delay(project_id="PRJ-001", session=session)
        print("Success:", res)
    except Exception as e:
        import traceback
        traceback.print_exc()
