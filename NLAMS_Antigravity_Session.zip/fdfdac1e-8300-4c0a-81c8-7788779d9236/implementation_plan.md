# Implementation Plan - Role-Based JWT Authentication & Protected Access Control

Integrate end-to-end Role-Based Access Control (RBAC) into NLAMS using JWT authentication, password hashing, pre-seeded government demo credentials, and frontend auth state management.

## User Review Required

> [!IMPORTANT]
> **Key Security & User Experience Highlights:**
> 1. **5 Pre-seeded Hackathon Demo Accounts:**
>    * `ministry` / `nlams2026` (Central Ministry Node - Full Access)
>    * `state` / `nlams2026` (State GIS Officer - GIS Verification Stage)
>    * `collector` / `nlams2026` (District Magistrate - Sec 11 Notice & Award Declaration)
>    * `surveyor` / `nlams2026` (Field Surveyor - Ground GPS & Possession Handover)
>    * `citizen` / `nlams2026` (Citizen / Landowner - Compensation & Deed Verification)
> 2. **Authentication Flow:**
>    * FastAPI backend issues signed **JWT Bearer Tokens** upon successful credential verification.
>    * Tokens are stored securely in `localStorage` and sent via `Authorization: Bearer <token>` headers.
> 3. **Role-Restricted Endpoint Guards:**
>    * Workflow transitions (`/api/v1/projects/{id}/advance`) and proposal creations are protected by backend role dependencies.
> 4. **Quick Demo Login UI:**
>    * The login screen features a 1-click **"Quick Demo Login"** button panel for instant testing during judges' evaluation.

## Proposed Changes

### Backend (`/backend/home/nitesh/Downloads/M2_LAND_ACQUISITION/app`)

#### [MODIFY] [models.py](file:///c:/Users/win11/Downloads/sih/backend/home/nitesh/Downloads/M2_LAND_ACQUISITION/app/models.py)
- Add `User` SQLModel table schema (`id`, `username`, `full_name`, `hashed_password`, `role`, `department`, `created_at`).
- Add `UserRead` and `UserLogin` schemas.

#### [NEW] [auth.py](file:///c:/Users/win11/Downloads/sih/backend/home/nitesh/Downloads/M2_LAND_ACQUISITION/app/routers/auth.py)
- `POST /api/v1/auth/login`: Authenticates credentials using `passlib.bcrypt` and issues JWT token.
- `GET /api/v1/auth/me`: Returns details of current authenticated user.

#### [MODIFY] [dependencies.py](file:///c:/Users/win11/Downloads/sih/backend/home/nitesh/Downloads/M2_LAND_ACQUISITION/app/dependencies.py)
- Add JWT secret key & algorithm config (`HS256`).
- Add `get_current_user` OAuth2 Password Bearer dependency.
- Add `require_role(allowed_roles)` dependency factory to protect endpoints.

#### [MODIFY] [database.py](file:///c:/Users/win11/Downloads/sih/backend/home/nitesh/Downloads/M2_LAND_ACQUISITION/app/database.py)
- Seed 5 demo accounts into `user` table on startup if empty.

#### [MODIFY] [main.py](file:///c:/Users/win11/Downloads/sih/backend/home/nitesh/Downloads/M2_LAND_ACQUISITION/app/main.py)
- Register `auth.router` under `/api/v1/auth`.

---

### Frontend (`/frontend/src`)

#### [NEW] [Login.jsx](file:///c:/Users/win11/Downloads/sih/frontend/src/pages/Login.jsx)
- Sleek Government portal login interface with username/password inputs and 1-click Quick Login preset buttons.

#### [MODIFY] [AppContext.jsx](file:///c:/Users/win11/Downloads/sih/frontend/src/context/AppContext.jsx)
- Add auth state (`user`, `token`, `isAuthenticated`, `login`, `logout`).
- Inject JWT bearer token in request headers for all mutation APIs.

#### [MODIFY] [Navbar.jsx](file:///c:/Users/win11/Downloads/sih/frontend/src/components/Navbar.jsx)
- Display active user profile badge, department, role, and a Logout button.

#### [MODIFY] [App.jsx](file:///c:/Users/win11/Downloads/sih/frontend/src/App.jsx)
- Integrate Login screen modal/view and protected page guards.

## Verification Plan

### Automated Verification
1. Run `python -m uvicorn app.main:app` and verify startup initialization of demo user accounts.
2. Run `npm run build` in `/frontend` to verify 0 syntax/compilation errors.

### Manual Verification
1. Open the portal and click **Login**.
2. Test 1-click login as `District Collector`.
3. Try executing an action (e.g. advance workflow stage).
4. Log out and log in as `Field Surveyor` to verify role-restricted actions are updated.
