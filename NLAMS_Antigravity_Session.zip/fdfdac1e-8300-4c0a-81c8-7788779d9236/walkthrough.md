# NLAMS Project Expansion & Upgrades Walkthrough

We have successfully expanded the **National Land Acquisition & Management System (NLAMS)** prototype with advanced features, real-time machine learning predictions, and role-based authentication.

## Key Upgrades Made

### 1. 🔑 Role-Based JWT Authentication & Protected Access Control
* **Backend Security:** Built a dedicated authentication module [`auth.py`](file:///c:/Users/win11/Downloads/sih/backend/home/nitesh/Downloads/M2_LAND_ACQUISITION/app/routers/auth.py) issuing signed **JWT Bearer tokens** upon credential validation.
* **Pre-Seeded Demo Accounts:** Automatically seeds 5 official role accounts into SQLite on startup:
  * **Central Ministry:** `ministry` / `nlams2026` (Dr. Rajesh Verma - Ministry of Road Transport & Highways)
  * **State Government:** `state` / `nlams2026` (Priya Sundaram - State Remote Sensing Centre)
  * **District Collector:** `collector` / `nlams2026` (Amitabh Choudhury IAS - Office of District Magistrate)
  * **Field Surveyor:** `surveyor` / `nlams2026` (Suresh Kumar - Cadastral Survey Station #04)
  * **Citizen / Landowner:** `citizen` / `nlams2026` (Rameshwar Patel - Registered Landholder Portal)
* **Frontend Login UI ([`Login.jsx`](file:///c:/Users/win11/Downloads/sih/frontend/src/pages/Login.jsx)):** Designed a high-contrast government login modal featuring a 1-click **Quick Demo Login** button panel for instant hackathon evaluation.
* **Header Profile Badge:** [`Navbar.jsx`](file:///c:/Users/win11/Downloads/sih/frontend/src/components/Navbar.jsx) displays the logged-in user's full name, department, role tag, and Logout button.

### 2. 🧠 Real Machine Learning Engine (Scikit-Learn Model & REST Inference API)
* **The Script:** Created [`train_model.py`](file:///c:/Users/win11/Downloads/sih/backend/home/nitesh/Downloads/M2_LAND_ACQUISITION/train_model.py) which pulls project attributes (State, Sector, Area, Budget) from SQLite, encodes categoricals, fits scikit-learn models (`DecisionTreeClassifier` for risk and `DecisionTreeRegressor` for completion time), and serializes them to `land_delay_model.joblib`.
* **The API Endpoint:** Deployed `GET /api/v1/projects/{project_id}/predict` inside [`dashboard.py`](file:///c:/Users/win11/Downloads/sih/backend/home/nitesh/Downloads/M2_LAND_ACQUISITION/app/routers/dashboard.py) which loads weights and executes real-time inferences.
* **The Frontend Connector:** Modified [`Dashboard.jsx`](file:///c:/Users/win11/Downloads/sih/frontend/src/pages/Dashboard.jsx) to make an active API call on project selection, rendering real-time ML metrics on the webpage DOM.

### 3. 🌐 Full Bilingual Support (Hindi / English Switcher)
* **The Toggle:** Added a global language selector (Globe Icon button) to the top navigation bar.
* **The Translation Map:** Created an extensive translation dictionary [`Translation.js`](file:///c:/Users/win11/Downloads/sih/frontend/src/context/Translation.js) mapping headings, statistics cards, profile select menus, form fields, and status items.
* **Legal Parchment & Receipts:** Switching the language dynamically translates the **Gazette of India / Bharat ka Rajpatra** notices and the **Direct Benefit Transfer (DBT) Treasury Receipts** into formal, legal Hindi.

### 4. 📱 Simulated Mobile Alert System (SMS/WhatsApp Alerts)
* **The Component:** Built an animated, floating government mobile notification bubble [`SMSSimulator.jsx`](file:///c:/Users/win11/Downloads/sih/frontend/src/components/SMSSimulator.jsx) anchored to the bottom-right corner.
* **Trigger Mechanics:** Fired automatically during key operations (Proposal Submission, GIS Boundaries Locked, Section 11 Notices, Escrow Payouts).

### 5. 💾 Enterprise-Scale Seeding (2,501 Records)
* Populated SQLite database with 41 Infrastructure Projects across 6 states, 1,500 Land Parcels, and 960 R&R Beneficiaries.

---

## Technical Verification Summary
* Verified compilation passes cleanly via `npm run build` (compiled successfully with 0 errors).
* The backend API server is fully online on port 8000 with `/api/v1/auth/login` and `/api/v1/auth/me`.
* Both backend and frontend services are exposed via concurrent Cloudflare quick tunnels.
