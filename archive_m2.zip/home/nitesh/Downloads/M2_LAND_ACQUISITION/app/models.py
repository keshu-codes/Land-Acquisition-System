from datetime import datetime
from typing import Optional, List

from sqlmodel import Field, SQLModel, Relationship

class ProjectBase(SQLModel):
    name: str = Field(index=True)
    ministry: Optional[str] = None
    sector: Optional[str] = None
    total_area: Optional[float] = None
    budget: Optional[float] = None
    state: Optional[str] = None
    district: Optional[str] = None
    status: Optional[str] = None

class Project(ProjectBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    parcels: List["Parcel"] = Relationship(back_populates="project")
    notifications: List["Notification"] = Relationship(back_populates="project")

class ProjectRead(ProjectBase):
    id: int
    created_at: datetime

class ParcelBase(SQLModel):
    parcel_number: str
    owner_name: Optional[str] = None
    survey_number: Optional[str] = None
    area_sqm: Optional[float] = None
    valuation: Optional[float] = None
    compensation_status: Optional[str] = None
    geojson_geometry: Optional[str] = None  # store as JSON string

class Parcel(ParcelBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    project_id: int = Field(foreign_key="project.id")
    project: Project = Relationship(back_populates="parcels")
    beneficiaries: List["Beneficiary"] = Relationship(back_populates="parcel")

class ParcelRead(ParcelBase):
    id: int
    project_id: int

class NotificationBase(SQLModel):
    section_type: str = Field(..., description="One of: Sec 4, Sec 11, Sec 19")
    issue_date: datetime = Field(default_factory=datetime.utcnow)
    status: Optional[str] = None

class Notification(NotificationBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    project_id: int = Field(foreign_key="project.id")
    project: Project = Relationship(back_populates="notifications")

class NotificationRead(NotificationBase):
    id: int
    project_id: int

class BeneficiaryBase(SQLModel):
    family_head: Optional[str] = None
    affected_members: Optional[int] = None
    compensation_assessed: Optional[float] = None
    compensation_paid: Optional[float] = None
    rr_status: Optional[str] = None

class Beneficiary(BeneficiaryBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    parcel_id: int = Field(foreign_key="parcel.id")
    parcel: Parcel = Relationship(back_populates="beneficiaries")

class BeneficiaryRead(BeneficiaryBase):
    id: int
    parcel_id: int
