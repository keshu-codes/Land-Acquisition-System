import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import projects, parcels, beneficiaries, dashboard

# Application instance
app = FastAPI(title="National Land Acquisition System API", version="1.0.0")

# CORS configuration
origins = [
    "http://localhost:3000",
    "http://localhost:5173",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers under /api/v1
app.include_router(projects.router, prefix="/api/v1", tags=["projects"])
app.include_router(parcels.router, prefix="/api/v1", tags=["parcels"])
app.include_router(beneficiaries.router, prefix="/api/v1", tags=["beneficiaries"])
app.include_router(dashboard.router, prefix="/api/v1", tags=["dashboard"])

# Hook for dynamic dependency injection (e.g., security)
def add_security_dependency(dependency):
    """Inject a dependency into all routers for authentication/authorization.
    The function should be called before the app starts serving.
    Example:
        from fastapi import Security
        def get_current_user(...): ...
        add_security_dependency(Security(get_current_user, scopes=[]))
    """
    for router in [projects.router, parcels.router, beneficiaries.router, dashboard.router]:
        router.dependencies.append(dependency)



# Initialize database on startup
@app.on_event("startup")
def on_startup():
    from .database import init_db
    init_db()
