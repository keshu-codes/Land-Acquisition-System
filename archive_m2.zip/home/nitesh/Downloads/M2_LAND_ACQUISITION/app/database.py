from sqlmodel import SQLModel, create_engine, Session
import os

# Determine database URL; fallback to SQLite if not provided via env
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./land_acquisition.db")

# Create engine with appropriate connect args for SQLite
engine = create_engine(
    DATABASE_URL,
    echo=False,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
)

def init_db():
    """Create all tables in the database."""
    SQLModel.metadata.create_all(engine)

# Dependency for fastapi routes
def get_session():
    with Session(engine) as session:
        yield session
